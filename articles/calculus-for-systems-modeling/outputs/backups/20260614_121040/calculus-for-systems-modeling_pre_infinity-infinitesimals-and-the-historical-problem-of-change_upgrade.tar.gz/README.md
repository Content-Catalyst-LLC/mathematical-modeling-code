# Calculus for Systems Modeling

Companion repository folder for the **Calculus for Systems Modeling** article map and nested article-level workflows.

This folder supports calculus-based systems modeling across continuous change, functions, variables, mathematical representation, domains, ranges, valid input spaces, output ranges, constraints, rates, accumulation, optimization, differential equations, numerical approximation, simulation, sensitivity analysis, responsible interpretation, and reproducible scientific-computing workflows.

## Nested article folders

Article-specific code lives under:

```text
articles/calculus-for-systems-modeling/articles/
```

Current active article companion folders:

```text
articles/calculus-for-systems-modeling/articles/what-is-calculus-for-systems-modeling/
articles/calculus-for-systems-modeling/articles/functions-variables-and-mathematical-representation/
articles/calculus-for-systems-modeling/articles/domains-ranges-and-the-structure-of-functional-models/
```

## Standard article folder structure

Each nested article folder may include Python, R, Julia, SQL, Haskell, C, C++, Fortran, Rust, Go, notebooks, docs, data, outputs, schemas, Canvas artifacts, README.md, Makefile, article-metadata.yml, and github-embed-wordpress.html.

## General principles

- Keep models transparent.
- Make assumptions explicit.
- Separate synthetic teaching data from real-world datasets.
- Document parameters, uncertainty, and limitations.
- Use reproducible workflows.
- Treat computation as support for interpretation, not a substitute for judgment.
- Keep examples educational, auditable, and extensible.

## Run smoke checks

```bash
make smoke
```
