# Calculus for Systems Modeling

Companion repository folder for the **Calculus for Systems Modeling** article map and nested article-level workflows.

This folder supports calculus-based systems modeling across continuous change, functions, variables, mathematical representation, domains, ranges, valid input spaces, infinity, infinitesimals, limits, continuity, discontinuity, structural breaks, approximation, rates, accumulation, optimization, differential equations, numerical methods, sensitivity analysis, responsible interpretation, and reproducible scientific-computing workflows.

## Nested article folders

Article-specific code lives under:

```text
articles/calculus-for-systems-modeling/articles/
```

Current active article companion folders:

```text
articles/calculus-for-systems-modeling/articles/what-is-calculus-for-systems-modeling/
articles/calculus-for-systems-modeling/articles/functions-variables-and-mathematical-representation/
articles/calculus-for-systems-modeling/articles/domains-ranges-and-the-structure-of-functional-models/
articles/calculus-for-systems-modeling/articles/infinity-infinitesimals-and-the-historical-problem-of-change/
articles/calculus-for-systems-modeling/articles/limits-and-the-formal-basis-of-calculus/
articles/calculus-for-systems-modeling/articles/continuity-discontinuity-and-structural-breaks/
```

## Advanced mathematical standard

All active article folders should include an `advanced/` layer designed for mathematicians, applied mathematicians, numerical analysts, and mathematically mature scientific-computing readers.

Future articles should include:

- formal mathematical deepening sections;
- definitions, propositions, counterexamples, and boundary cases;
- codomain/image/range distinctions where relevant;
- feasible sets, invariant sets, and state spaces where relevant;
- continuity, differentiability, compactness, smoothness, boundedness, or measurability assumptions where relevant;
- convergence, stability, conditioning, and numerical-error notes where computation is involved;
- stronger tests beyond smoke checks;
- generated Markdown/JSON audit reports.

## Run smoke checks

```bash
make smoke
```

## Run advanced checks

```bash
make advanced
```
